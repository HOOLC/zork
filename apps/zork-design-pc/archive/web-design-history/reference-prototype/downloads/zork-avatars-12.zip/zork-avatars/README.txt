12 original zork avatar studies. SVG master: 64x64 viewBox; PNG export: 256x256.
Existing IDs preserved: cat, bunny, bear, fox, panda, chick.
New IDs: dog, owl, koala, penguin, deer, octopus.
Not integrated into the production app yet.
